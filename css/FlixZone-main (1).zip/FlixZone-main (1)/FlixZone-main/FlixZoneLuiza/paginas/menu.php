

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menu Exemplo</title>
  <link rel="stylesheet" href="../css/menu.css">
</head>
<body>

  <nav class="menu">
    <ul>
      <li id="titulo1">FlixZone</li>
      <li><a href="TelaAlterar_item.php">Alterar</a></li>
      <li><a href="add_filme.php">Adicionar</a></li>
      <li><a href="#">Pesquisar</a></li>
      <li><a href="excluir_item.php">Excluir</a></li>
    </ul>
  </nav>
</body>
</html>
